package io.bumo.mall.talent.domain;

import java.util.Date;

public class BcTxRecord {
	private Long id;
	private String fromAddress;
	private String toAddress;
	private String assetCode;
	private String assetIssuer;
	private Integer assetDecimal;
	private Integer txStatus;
	private String txHash;
	private Integer bizType;
	private String transferAmount;
	private String optMetadata;
	private Date createTime;
	private Date updateTime;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getFromAddress() {
		return fromAddress;
	}
	public void setFromAddress(String fromAddress) {
		this.fromAddress = fromAddress;
	}
	public String getToAddress() {
		return toAddress;
	}
	public void setToAddress(String toAddress) {
		this.toAddress = toAddress;
	}
	public String getAssetCode() {
		return assetCode;
	}
	public void setAssetCode(String assetCode) {
		this.assetCode = assetCode;
	}
	public String getAssetIssuer() {
		return assetIssuer;
	}
	public void setAssetIssuer(String assetIssuer) {
		this.assetIssuer = assetIssuer;
	}
	public Integer getAssetDecimal() {
		return assetDecimal;
	}
	public void setAssetDecimal(Integer assetDecimal) {
		this.assetDecimal = assetDecimal;
	}
	public Integer getTxStatus() {
		return txStatus;
	}
	public void setTxStatus(Integer txStatus) {
		this.txStatus = txStatus;
	}
	public String getTxHash() {
		return txHash;
	}
	public void setTxHash(String txHash) {
		this.txHash = txHash;
	}
	public Integer getBizType() {
		return bizType;
	}
	public void setBizType(Integer bizType) {
		this.bizType = bizType;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	public String getTransferAmount() {
		return transferAmount;
	}
	public void setTransferAmount(String transferAmount) {
		this.transferAmount = transferAmount;
	}
	public String getOptMetadata() {
		return optMetadata;
	}
	public void setOptMetadata(String optMetadata) {
		this.optMetadata = optMetadata;
	}
	
}
