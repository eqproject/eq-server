package io.bumo.mall.talent.domain;

import java.util.Date;

public class BlockChainTX {
	private long id;
	private String txHash;
	private String txInitiatorAddress;
	private String txBlob;
	private String txFee;
	private String bizType;
	private Integer txStatus;
	private String bcErrorCode;
	private String bcErrorMsg;
	private Date createTime;
	private Date updateTime;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getTxHash() {
		return txHash;
	}
	public void setTxHash(String txHash) {
		this.txHash = txHash;
	}
	public String getTxInitiatorAddress() {
		return txInitiatorAddress;
	}
	public void setTxInitiatorAddress(String txInitiatorAddress) {
		this.txInitiatorAddress = txInitiatorAddress;
	}
	public String getTxBlob() {
		return txBlob;
	}
	public void setTxBlob(String txBlob) {
		this.txBlob = txBlob;
	}
	public String getTxFee() {
		return txFee;
	}
	public void setTxFee(String txFee) {
		this.txFee = txFee;
	}
	public Integer getTxStatus() {
		return txStatus;
	}
	public void setTxStatus(Integer txStatus) {
		this.txStatus = txStatus;
	}
	public String getBcErrorCode() {
		return bcErrorCode;
	}
	public void setBcErrorCode(String bcErrorCode) {
		this.bcErrorCode = bcErrorCode;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	public String getBizType() {
		return bizType;
	}
	public void setBizType(String bizType) {
		this.bizType = bizType;
	}
	public String getBcErrorMsg() {
		return bcErrorMsg;
	}
	public void setBcErrorMsg(String bcErrorMsg) {
		this.bcErrorMsg = bcErrorMsg;
	}
	
}
