package io.bumo.mall.talent.external.accountCenter.resp;

public class AccountCenterRegisterResp {

	private String address;

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

}
