package io.bumo.mall.talent.external.bc.resp;

public class BlobDataResp {
	private String blob;
	private String hash;
	public String getBlob() {
		return blob;
	}
	public void setBlob(String blob) {
		this.blob = blob;
	}
	public String getHash() {
		return hash;
	}
	public void setHash(String hash) {
		this.hash = hash;
	}
	
	
}
