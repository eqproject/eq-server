package io.bumo.mall.talent.external.bc.req;
public class SignEntity{
	private String signBlob;
	private String publicKey;
	public String getSignBlob() {
		return signBlob;
	}
	public void setSignBlob(String signBlob) {
		this.signBlob = signBlob;
	}
	public String getPublicKey() {
		return publicKey;
	}
	public void setPublicKey(String publicKey) {
		this.publicKey = publicKey;
	}
	
	
}