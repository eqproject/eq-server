package io.bumo.mall.talent.common;

import java.util.UUID;

public class UUIDGenerator {
	
	public static String getUUID32() {
		return UUID.randomUUID().toString().replace("-", "").toLowerCase();
	}

}
